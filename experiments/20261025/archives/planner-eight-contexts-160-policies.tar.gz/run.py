import pathlib,json,os,subprocess,sys,time,hashlib
root=pathlib.Path('/work/planner-matrix-v2');os.nice(19)
env=os.environ.copy();env.update({'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','CUDA_VISIBLE_DEVICES':''})
index=json.loads((root/'index.json').read_text());status={'kind':'sequential_cpu_measured_PPO_matrix','start_epoch':time.time(),'nice':os.nice(0),'threads':1,'npu_used':False,'gpu_used':False,'runs':[]}
def save():
 p=root/'status.tmp';p.write_text(json.dumps(status,indent=2));p.replace(root/'status.json')
save()
for e in index:
 name=pathlib.Path(e['file']).stem;out=root/'results'/(name+'.json')
 cmd=[sys.executable,str(root/'methods/analyze_measured.py'),'--input',str(root/'tasks'/pathlib.Path(e['file']).name),'--output',str(out),'--budget','2','--steps','4096','--seeds','11','22','33','44','55','--with-embedding']
 started=time.time()
 with (root/'results'/(name+'.log')).open('x') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 status['runs'].append({'task_id':e['task_id'],'device_id':e['device_id'],'start_epoch':started,'finish_epoch':time.time(),'exit_code':r.returncode,'command':cmd,'output':str(out)})
 save()
 if r.returncode:raise SystemExit(r.returncode)
status['completed_epoch']=time.time();save()
