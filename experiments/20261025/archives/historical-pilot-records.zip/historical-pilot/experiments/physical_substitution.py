"""New post-submission local mechanism test; never a rerun of the paper corpus.

Four semantically equivalent FP32 implementation substitutions on ONE backend.
All 16 coalitions are measured, without fitting their outcomes to the proxy.
One invocation is one complete independent timing block. Parent orchestrates
fresh processes, and never measures two local backends concurrently.
"""
import argparse
import hashlib
import itertools
import json
import math
import os
import platform
import random
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
import torch.nn.functional as F

NAMES = ['Linear', 'ExactGELU', 'LayerNorm', 'Attention']
SHAPES = [(1, 64, 128, 4), (4, 128, 256, 8)]


def sync(device):
    if device.type == 'cuda': torch.cuda.synchronize(device)
    elif device.type == 'mps': torch.mps.synchronize()
    elif device.type == 'npu': torch.npu.synchronize()


def exact_shapley(values, n=4):
    out = []
    for i in range(n):
        total = 0.0
        for m in range(1 << n):
            if m & (1 << i): continue
            k = m.bit_count()
            weight = math.factorial(k) * math.factorial(n-k-1) / math.factorial(n)
            # Benefit game: positive means measured latency decreases.
            total += weight * (values[m] - values[m | (1 << i)])
        out.append(total)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--device', choices=['cpu','mps','cuda','npu'], required=True)
    ap.add_argument('--shape', type=int, choices=[0,1], required=True)
    ap.add_argument('--run', type=int, required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--repeats', type=int, default=40)
    ap.add_argument('--warmup', type=int, default=10)
    args = ap.parse_args()
    out = Path(args.output)
    if out.exists(): raise RuntimeError('Never overwrite a prior timing block: '+str(out))
    if args.device == 'npu': import torch_npu  # noqa: F401
    device = torch.device(args.device)
    if args.device == 'mps' and not torch.backends.mps.is_available():
        raise RuntimeError('MPS unavailable; do not silently substitute CPU')
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; do not silently substitute CPU')
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    if hasattr(torch.backends, 'cuda'):
        torch.backends.cuda.matmul.allow_tf32 = False
    if hasattr(torch.backends, 'cudnn'):
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
    torch.manual_seed(42)
    b, s, d, heads = SHAPES[args.shape]
    x0 = torch.randn(b, s, d, dtype=torch.float32)
    w0 = torch.randn(d, d, dtype=torch.float32) / math.sqrt(d)
    bias0 = torch.randn(d, dtype=torch.float32) / 10
    normw0 = torch.randn(d, dtype=torch.float32) / 10 + 1
    normb0 = torch.randn(d, dtype=torch.float32) / 10
    tensor_hash = hashlib.sha256(b''.join(t.contiguous().numpy().tobytes()
        for t in [x0,w0,bias0,normw0,normb0])).hexdigest()
    x,w,bias,nw,nb = [t.to(device) for t in [x0,w0,bias0,normw0,normb0]]

    def op(i, z, optimized):
        if i == 0:
            return F.linear(z,w,bias) if optimized else torch.matmul(z,w.t()) + bias
        if i == 1:
            return F.gelu(z, approximate='none') if optimized else 0.5*z*(1+torch.erf(z/math.sqrt(2)))
        if i == 2:
            if optimized: return F.layer_norm(z,(d,),nw,nb,1e-5)
            mean=z.mean(dim=-1,keepdim=True)
            var=((z-mean)**2).mean(dim=-1,keepdim=True)
            return (z-mean)*torch.rsqrt(var+1e-5)*nw+nb
        q=z.reshape(b,s,heads,d//heads).transpose(1,2)
        if optimized:
            a=F.scaled_dot_product_attention(q,q,q,dropout_p=0.0,is_causal=False)
        else:
            a=torch.softmax(torch.matmul(q,q.transpose(-2,-1))/math.sqrt(d//heads),dim=-1) @ q
        return a.transpose(1,2).contiguous().reshape(b,s,d)

    def model(mask):
        z=x
        for i in range(4):z=op(i,z,bool(mask & (1 << i)))
        return z

    def timed(fn):
        for _ in range(args.warmup):fn()
        sync(device)
        samples=[]
        for _ in range(args.repeats):
            sync(device)
            t=time.perf_counter_ns()
            fn()
            sync(device)
            samples.append((time.perf_counter_ns()-t)/1e6)
        return {'mean_ms':statistics.mean(samples),
                'median_ms':statistics.median(samples),
                'sd_ms':statistics.stdev(samples), 'samples_ms':samples}

    with torch.inference_mode():
        # Profile independent isolated implementations before observing coalitions.
        inputs=[x];z=x
        for i in range(3):z=op(i,z,False);inputs.append(z)
        standalone=[]
        for i in range(4):
            timings={}
            impl_order=[0,1];random.Random(3000+args.run*10+i).shuffle(impl_order)
            for opt in impl_order:timings[str(opt)]=timed(lambda:op(i,inputs[i],bool(opt)))
            standalone.append({'operator':NAMES[i], 'baseline':timings['0'],
                'candidate':timings['1'],
                'proxy_benefit_ms':timings['0']['mean_ms']-timings['1']['mean_ms']})
        proxy_rank=sorted(range(4),key=lambda i:(-standalone[i]['proxy_benefit_ms'],i))
        latency_rank=sorted(range(4),key=lambda i:(-standalone[i]['baseline']['mean_ms'],i))
        frozen_at=datetime.now(timezone.utc).isoformat()
        reference=model(0);sync(device)
        order=list(range(16));random.Random(1000+args.run).shuffle(order)
        coalitions={}
        for mask in order:
            actual=model(mask);sync(device)
            torch.testing.assert_close(actual,reference,atol=1e-4,rtol=1e-4)
            diff=actual-reference
            quality={'max_abs_error':float(diff.abs().max().item()),
                'relative_l2_error':float((diff.norm()/reference.norm().clamp_min(1e-12)).item()),
                'allclose_atol':1e-4,'allclose_rtol':1e-4,'passed':True}
            coalitions[str(mask)]={'mask':mask,'operators':[NAMES[i] for i in range(4) if mask & (1<<i)],
                'quality':quality,**timed(lambda:model(mask))}
        vals={m:coalitions[str(m)]['mean_ms'] for m in range(16)}
        phi=exact_shapley(vals)
        oracle_rank=sorted(range(4),key=lambda i:(-phi[i],i))
        baseline=vals[0]
        strategies={}
        for k in [1,2]:
            masks=[m for m in range(16) if m.bit_count()==k]
            for name,rank in [('frozen_standalone_proxy',proxy_rank),('latency',latency_rank),('measured_oracle',oracle_rank)]:
                m=sum(1<<i for i in rank[:k])
                strategies[f'{name}_k{k}']={'mask':m,'benefit_percent':100*(baseline-vals[m])/baseline}
            strategies[f'random_all_subsets_mean_k{k}']={'mask_count':len(masks),
                'benefit_percent':statistics.mean(100*(baseline-vals[m])/baseline for m in masks)}
        info={'utc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),
            'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),
            'torch':torch.__version__,'cuda_version':torch.version.cuda,
            'backend':str(device),'threads':torch.get_num_threads(),
            'shape':[b,s,d,heads],'dtype':'float32','model_seed':42,
            'input_weights_sha256':tensor_hash,'run':args.run,
            'warmup_per_coalition':args.warmup,'timed_repeats_per_coalition':args.repeats,
            'timing':'synchronized wall clock per call; includes dispatch/synchronization',
            'scope':'new four-block same-backend substitution micrograph; not 34-model or migration validation',
            'graph':'single serial chain; critical-path max equals sum',
            'proxy_frozen_before_coalition_measurement_utc':frozen_at,
            'coalition_order':order,'standalone_profiles':standalone,
            'frozen_proxy_rank':[NAMES[i] for i in proxy_rank],
            'frozen_latency_rank':[NAMES[i] for i in latency_rank],
            'coalitions':coalitions,'measured_shapley_benefit_ms':dict(zip(NAMES,phi)),
            'efficiency_residual_ms':sum(phi)-(vals[0]-vals[15]),
            'strategies_same_run_descriptive_not_unbiased':strategies}
        if device.type=='cuda':
            info['gpu']=torch.cuda.get_device_name(0)
            info['gpu_memory_bytes']=torch.cuda.get_device_properties(0).total_memory
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(info,indent=2,ensure_ascii=False))
        print(json.dumps({'output':str(out),'backend':str(device),'shape':args.shape,'run':args.run,
            'baseline_ms':vals[0],'candidate_ms':vals[15],'shapley_ms':phi,'quality':'16/16 passed'}),flush=True)


if __name__=='__main__':main()
