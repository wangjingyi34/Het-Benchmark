"""Auditable aggregation of new local measurements, not submitted-corpus validation."""
import csv
import argparse
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAMES = ['Linear', 'ExactGELU', 'LayerNorm', 'Attention']

def stats(x):
    return {'n': len(x), 'mean': statistics.mean(x),
            'sample_sd': statistics.stdev(x) if len(x) > 1 else None,
            'min': min(x), 'max': max(x), 'values': x}

def exact(values):
    # Independent permutation enumeration rather than subset weights in runner.
    totals = [0.0] * 4
    for p in itertools.permutations(range(4)):
        m = 0
        for i in p:
            nxt = m | (1 << i)
            totals[i] += values[m] - values[nxt]
            m = nxt
    return [v / 24 for v in totals]

def benefit(values, mask):
    return 100.0 * (values[0] - values[mask]) / values[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', type=Path, default=ROOT / 'evidence/physical')
    args = ap.parse_args()
    args.source = args.source.resolve()
    rows = []
    groups = {}
    sources = {}
    checks = []
    for path in sorted(args.source.glob('*.json')):
        d = json.loads(path.read_text())
        sources[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
        c = d['coalitions']
        assert set(c) == set(map(str, range(16)))
        vals = [c[str(m)]['mean_ms'] for m in range(16)]
        assert all(math.isfinite(x) and x > 0 for x in vals)
        for m in range(16):
            samples = c[str(m)]['samples_ms']
            assert len(samples) == 40 and all(math.isfinite(x) and x > 0 for x in samples)
            assert abs(statistics.mean(samples) - vals[m]) < 1e-10
            assert c[str(m)]['quality']['passed'] is True
        phi = exact(vals)
        median_vals = [c[str(m)]['median_ms'] for m in range(16)]
        median_phi = exact(median_vals)
        cvs = [c[str(m)]['sd_ms'] / vals[m] for m in range(16)]
        assert max(abs(a - d['measured_shapley_benefit_ms'][name])
                   for a, name in zip(phi, NAMES)) < 1e-10
        residual = sum(phi) - (vals[0] - vals[15])
        assert abs(residual) < 1e-10
        assert d['proxy_frozen_before_coalition_measurement_utc'] < d['utc']
        shape_id = 0 if d['shape'] == [1, 64, 128, 4] else 1
        assert d['shape'] in [[1, 64, 128, 4], [4, 128, 256, 8]]
        key = f"{d['backend']}-s{shape_id}"
        groups.setdefault(key, []).append((d, vals))
        rows.append({'group': key, 'run': d['run'], 'baseline_ms': vals[0],
                     'all_substitutions_ms': vals[15], 'benefit_percent': benefit(vals, 15),
                     'median_based_benefit_percent': benefit(median_vals, 15),
                     'mean_median_benefit_sign_disagree': (benefit(vals,15) < 0) != (benefit(median_vals,15) < 0),
                     'within_coalition_cv_median': statistics.median(cvs),
                     'within_coalition_cv_max': max(cvs),
                     'mean_phi_ms': dict(zip(NAMES, phi)),
                     'median_phi_ms': dict(zip(NAMES, median_phi)),
                     'max_abs_error': max(c[str(m)]['quality']['max_abs_error'] for m in range(16)),
                     'efficiency_residual_ms': residual})
        checks.append({'file': path.name, 'all_16_equivalent': True,
                       '40_samples_each_recomputed': True,
                       'shapley_independent_24_permutation_check': True})
    summary = {}
    pair_rows = []
    for key, entries in groups.items():
        entries.sort(key=lambda x: x[0]['run'])
        assert [d['run'] for d, _ in entries] == [1, 2, 3, 4, 5]
        assert len({d['input_weights_sha256'] for d, _ in entries}) == 1
        s = {'backend': entries[0][0]['backend'], 'shape': entries[0][0]['shape'],
             'fixed_model_seed': 42, 'fresh_timing_processes': 5,
             'all_substitutions_benefit_percent': stats([benefit(v, 15) for _, v in entries]),
             'median_based_all_substitutions_benefit_percent': stats([
                 benefit([d['coalitions'][str(m)]['median_ms'] for m in range(16)],15)
                 for d,_ in entries]),
             'mean_median_sign_disagreement_runs': [r['run'] for r in rows if r['group']==key and r['mean_median_benefit_sign_disagree']],
             'max_abs_error': max(r['max_abs_error'] for r in rows if r['group'] == key),
             'negative_full_plan_runs': [d['run'] for d, v in entries if benefit(v, 15) < 0],
             'cross_run_next_block': {}}
        for k in [1, 2]:
            items = []
            for (previous, _), (current, vals) in zip(entries, entries[1:]):
                ranks = {'standalone_proxy': previous['frozen_proxy_rank'],
                         'latency': previous['frozen_latency_rank']}
                gains = {}
                for name, rank in ranks.items():
                    mask = sum(1 << NAMES.index(op) for op in rank[:k])
                    gains[name] = benefit(vals, mask)
                masks = [m for m in range(16) if m.bit_count() == k]
                gains['uniform_random_subset_expectation'] = statistics.mean(benefit(vals, m) for m in masks)
                item = {'group': key, 'k': k, 'rank_from_run': previous['run'],
                        'evaluate_run': current['run'], **gains}
                item['proxy_minus_latency_pp'] = gains['standalone_proxy'] - gains['latency']
                item['proxy_minus_random_pp'] = gains['standalone_proxy'] - gains['uniform_random_subset_expectation']
                items.append(item)
                pair_rows.append(item)
            s['cross_run_next_block'][str(k)] = {
                field: stats([r[field] for r in items]) for field in
                ['standalone_proxy', 'latency', 'uniform_random_subset_expectation',
                 'proxy_minus_latency_pp', 'proxy_minus_random_pp']}
        summary[key] = s
    assert len(rows) == 5 * len(groups) and rows
    result = {
        'scope': 'New four-block FP32 same-backend substitution micrograph, fixed seed and tensors within each backend. Not COPA/PPO, not full models, not cross-chip validation.',
        'measurement_unit': 'One fresh-process timing block; repeated calls are within-block observations, not independent model samples.',
        'ranking_protocol': 'Previous timing block standalone profile freezes operator ranking; evaluate next block coalition timings, four adjacent pairs per backend/shape. No coalition outcome used to choose proxy. Fixed tensor workload within each backend, sequential timing blocks on shared host; descriptive only.',
        'random_baseline': 'Exact expected benefit over all size-k subsets, not a reported random-seed experiment.',
        'oracle_policy': 'Measured Shapley is recomputed for consistency only; it is not a held-out prediction strategy.',
        'sensitivity_policy': 'Both mean-latency and median-latency coalition games are retained. Median is sensitivity analysis, not substituted as the primary estimand after observing the result. High CV and sign changes invalidate stable superiority claims.',
        'counts': {'blocks': len(rows), 'coalition_equivalence_checks': len(rows)*16,
                   'timed_coalition_calls': len(rows)*16*40, 'coalition_warmups': len(rows)*16*10,
                   'timed_standalone_calls': len(rows)*8*40, 'standalone_warmups': len(rows)*8*10,
                   'cross_run_pairs_per_backend_shape': 4},
        'limitations': ['Four serial operator blocks in the micrograph; critical-path maximum equals sum.',
                       'Fixed seed 42 and tensors, not five independent models or training seeds.',
                       'atol/rtol equivalence is numerical, not task accuracy.',
                       'Synchronized wall-clock includes Python dispatch and synchronization.',
                       'CPU/MPS use a shared workstation; CUDA uses an isolated MIG partition on a shared cloud host. No full host or thermal isolation guaranteed.',
                       'Mean and sample SD are descriptive; no population confidence claim or significance test.',
                       'New standalone proxy ranking is not the submitted COPA estimator.'],
        'source_sha256': sources, 'checks': checks, 'groups': summary,
        'block_rows': rows, 'ranking_rows': pair_rows}
    out = args.source.parent
    (out / 'physical-summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False))
    for filename, items in [('physical-blocks.csv', rows), ('physical-ranking.csv', pair_rows)]:
        with (out / filename).open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(items[0]))
            writer.writeheader(); writer.writerows(items)
    print(json.dumps({'counts': result['counts'], 'groups': summary}, indent=2))

if __name__ == '__main__': main()
