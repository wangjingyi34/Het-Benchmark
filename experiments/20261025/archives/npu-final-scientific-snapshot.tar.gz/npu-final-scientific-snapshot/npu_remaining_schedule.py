"""Finish only physical NPU work, with bounded prerequisite wait and receipts."""
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/root/het-rebuttal-20261025')
STATE = ROOT / 'npu-remaining-state.json'
if STATE.exists():
    raise FileExistsError('Preserve earlier schedule; inspect it before restarting')
receipt = {'started_utc': datetime.now(timezone.utc).isoformat(), 'steps': []}
def save():
    tmp = STATE.with_suffix('.tmp'); tmp.write_text(json.dumps(receipt, indent=2)); tmp.replace(STATE)
save()
deadline = time.monotonic() + 2400
while True:
    matrix = json.loads((ROOT / 'fullmodel_raw/matrix-state-npu.json').read_text())
    if matrix.get('failed_command'):
        raise RuntimeError('Full matrix failed; inspect preserved command before continuing')
    if matrix.get('completed_utc'):
        assert len(matrix['runs']) == 32
        break
    if time.monotonic() > deadline:
        raise TimeoutError('NPU matrix did not finish within bounded wait')
    time.sleep(5)

N = str(ROOT / 'npu-python')
def execute(name, script, args):
    command = [N, str(ROOT / script)] + args
    started = datetime.now(timezone.utc).isoformat()
    log = ROOT / (name + '.log')
    with log.open('x') as f:
        result = subprocess.run(command, stdout=f, stderr=subprocess.STDOUT)
    receipt['steps'].append({'name':name,'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
                             'command':command,'exit_code':result.returncode,'log':str(log)})
    save()
    if result.returncode:
        raise RuntimeError('Failed step '+name+'; inspect log without overwriting evidence')

execute('capabilities-npu', 'interventions/hardware_capability_probes.py',
        ['--device','npu','--output',str(ROOT/'capabilities-npu.json')])
execute('quality-stress-npu', 'interventions/quality_stress.py',
        ['--device','npu','--model','resnet18','--assets',str(ROOT/'assets/imagenet-val200'),
         '--output',str(ROOT/'quality-stress-npu.json')])
execute('active-policy-export', 'prediction/active_fallback.py',
        ['policy','--summary',str(ROOT/'policy-assets/npu-policy-4source/summary.json'),
         '--checkpoint-dir',str(ROOT/'policy-assets/npu-policy-4source'),
         '--method','rgat','--feature-mode','probe','--split-id','model-fold0',
         '--output',str(ROOT/'active-policy-npu.json')])
execute('active-hardware-export', 'prediction/active_fallback.py',
        ['hardware','--profile',str(ROOT/'npub3.json'),'--output',str(ROOT/'npu-hardware-only.json')])
execute('active-fallback-npu', 'prediction/active_fallback.py',
        ['run','--policy',str(ROOT/'active-policy-npu.json'),
         '--hardware-only',str(ROOT/'npu-hardware-only.json'),'--device','npu',
         '--output',str(ROOT/'active-fallback-npu.json')])
receipt['physical_schedule_completed_utc'] = datetime.now(timezone.utc).isoformat()
receipt['backup_and_independent_audit_still_required'] = True
save()
print(json.dumps(receipt), flush=True)
