import json,os,pathlib,subprocess,sys,time,platform
root=pathlib.Path('/work/bridge-analysis-resnet50')
os.nice(19)
env=os.environ.copy()
env.update({'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'})
manifest=json.loads((root/'input-manifest.json').read_text())
status={'kind':'CPU_only_frozen_early_migration_bridge','started_epoch':time.time(),'python':sys.version,'platform':platform.platform(),'nice':os.nice(0),'threads':1,'paid_npu_used':False,'runs':[]}
def write():
 p=root/'status.tmp';p.write_text(json.dumps(status,indent=2));p.replace(root/'status.json')
write()
for row in manifest['pairs']:
 out=root/'results'/('a100-to-910b-'+row['context']+'.json')
 command=[sys.executable,str(root/'methods/migration_bridge.py'),'--source-task',str(root/row['source']),'--target-task',str(root/row['target']),'--output',str(out),'--raw-path-map',str(root/'raw-path-map.json'),'--budget','2','--permutations','500','--seed','42','--reference-permutations','5000','--reference-seed','90210']
 started=time.time();r=subprocess.run(command,env=env,capture_output=True,text=True)
 (root/'results'/('a100-to-910b-'+row['context']+'.stdout.txt')).write_text(r.stdout)
 (root/'results'/('a100-to-910b-'+row['context']+'.stderr.txt')).write_text(r.stderr)
 status['runs'].append({'context':row['context'],'command':command,'started_epoch':started,'finished_epoch':time.time(),'exit_code':r.returncode,'output':str(out),'stdout':r.stdout,'stderr':r.stderr})
 write()
 if r.returncode:raise SystemExit(r.returncode)
status['completed_epoch']=time.time();write()
